﻿namespace Block_5_Task_1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tB_1 = new TextBox();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            buttonADD = new Button();
            buttonSUB = new Button();
            buttonMULT = new Button();
            buttonDIV = new Button();
            buttonEQL = new Button();
            button0 = new Button();
            buttonClear = new Button();
            buttonPotenzieren = new Button();
            buttonWurzel = new Button();
            buttonLogarithmus = new Button();
            buttonFakultaet = new Button();
            buttonSinus = new Button();
            buttonCosinus = new Button();
            buttonTangens = new Button();
            buttonKomma = new Button();
            buttonDelete = new Button();
            buttonClearEverything = new Button();
            buttonPlusMinus = new Button();
            menuStrip1 = new MenuStrip();
            standartToolStripMenuItem = new ToolStripMenuItem();
            standartToolStripMenuItem1 = new ToolStripMenuItem();
            wissenschaftlichToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // tB_1
            // 
            tB_1.Font = new Font("Segoe UI", 30F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tB_1.Location = new Point(8, 30);
            tB_1.Multiline = true;
            tB_1.Name = "tB_1";
            tB_1.ReadOnly = true;
            tB_1.Size = new Size(283, 65);
            tB_1.TabIndex = 0;
            tB_1.TextAlign = HorizontalAlignment.Right;
            tB_1.TextChanged += tB_1_TextChanged;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.AppWorkspace;
            button1.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            button1.Location = new Point(9, 170);
            button1.Name = "button1";
            button1.Size = new Size(66, 63);
            button1.TabIndex = 2;
            button1.Text = "1";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.AppWorkspace;
            button2.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            button2.Location = new Point(81, 170);
            button2.Name = "button2";
            button2.Size = new Size(66, 63);
            button2.TabIndex = 3;
            button2.Text = "2";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.AppWorkspace;
            button3.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            button3.Location = new Point(153, 170);
            button3.Name = "button3";
            button3.Size = new Size(66, 63);
            button3.TabIndex = 4;
            button3.Text = "3";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.BackColor = SystemColors.AppWorkspace;
            button4.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            button4.Location = new Point(9, 239);
            button4.Name = "button4";
            button4.Size = new Size(66, 63);
            button4.TabIndex = 5;
            button4.Text = "4";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.BackColor = SystemColors.AppWorkspace;
            button5.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            button5.Location = new Point(81, 239);
            button5.Name = "button5";
            button5.Size = new Size(66, 63);
            button5.TabIndex = 6;
            button5.Text = "5";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.BackColor = SystemColors.AppWorkspace;
            button6.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            button6.Location = new Point(153, 239);
            button6.Name = "button6";
            button6.Size = new Size(66, 63);
            button6.TabIndex = 7;
            button6.Text = "6";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.BackColor = SystemColors.AppWorkspace;
            button7.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            button7.Location = new Point(9, 308);
            button7.Name = "button7";
            button7.Size = new Size(66, 63);
            button7.TabIndex = 8;
            button7.Text = "7";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.BackColor = SystemColors.AppWorkspace;
            button8.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            button8.Location = new Point(81, 308);
            button8.Name = "button8";
            button8.Size = new Size(66, 63);
            button8.TabIndex = 9;
            button8.Text = "8";
            button8.UseVisualStyleBackColor = false;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.BackColor = SystemColors.AppWorkspace;
            button9.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            button9.Location = new Point(153, 308);
            button9.Name = "button9";
            button9.Size = new Size(66, 63);
            button9.TabIndex = 10;
            button9.Text = "9";
            button9.UseVisualStyleBackColor = false;
            button9.Click += button9_Click;
            // 
            // buttonADD
            // 
            buttonADD.BackColor = SystemColors.AppWorkspace;
            buttonADD.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            buttonADD.Location = new Point(225, 101);
            buttonADD.Name = "buttonADD";
            buttonADD.Size = new Size(66, 63);
            buttonADD.TabIndex = 11;
            buttonADD.Text = "+";
            buttonADD.UseVisualStyleBackColor = false;
            buttonADD.Click += buttonADD_Click;
            // 
            // buttonSUB
            // 
            buttonSUB.BackColor = SystemColors.AppWorkspace;
            buttonSUB.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            buttonSUB.Location = new Point(225, 170);
            buttonSUB.Name = "buttonSUB";
            buttonSUB.Size = new Size(66, 63);
            buttonSUB.TabIndex = 12;
            buttonSUB.Text = "-";
            buttonSUB.UseVisualStyleBackColor = false;
            buttonSUB.Click += buttonSUB_Click;
            // 
            // buttonMULT
            // 
            buttonMULT.BackColor = SystemColors.AppWorkspace;
            buttonMULT.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            buttonMULT.Location = new Point(225, 239);
            buttonMULT.Name = "buttonMULT";
            buttonMULT.Size = new Size(66, 63);
            buttonMULT.TabIndex = 13;
            buttonMULT.Text = "x";
            buttonMULT.UseVisualStyleBackColor = false;
            buttonMULT.Click += buttonMULT_Click;
            // 
            // buttonDIV
            // 
            buttonDIV.BackColor = SystemColors.AppWorkspace;
            buttonDIV.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            buttonDIV.Location = new Point(225, 308);
            buttonDIV.Name = "buttonDIV";
            buttonDIV.Size = new Size(66, 63);
            buttonDIV.TabIndex = 14;
            buttonDIV.Text = "➗";
            buttonDIV.UseVisualStyleBackColor = false;
            buttonDIV.Click += buttonDIV_Click;
            // 
            // buttonEQL
            // 
            buttonEQL.BackColor = Color.PeachPuff;
            buttonEQL.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonEQL.Location = new Point(225, 377);
            buttonEQL.Name = "buttonEQL";
            buttonEQL.Size = new Size(66, 63);
            buttonEQL.TabIndex = 15;
            buttonEQL.Text = "=";
            buttonEQL.UseVisualStyleBackColor = false;
            buttonEQL.Click += buttonEQL_Click;
            // 
            // button0
            // 
            button0.BackColor = SystemColors.AppWorkspace;
            button0.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            button0.Location = new Point(81, 377);
            button0.Name = "button0";
            button0.Size = new Size(66, 63);
            button0.TabIndex = 16;
            button0.Text = "0";
            button0.UseVisualStyleBackColor = false;
            button0.Click += button0_Click;
            // 
            // buttonClear
            // 
            buttonClear.BackColor = SystemColors.AppWorkspace;
            buttonClear.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            buttonClear.Location = new Point(81, 101);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(66, 63);
            buttonClear.TabIndex = 17;
            buttonClear.Text = "C";
            buttonClear.UseVisualStyleBackColor = false;
            buttonClear.Click += buttonClear_Click_1;
            // 
            // buttonPotenzieren
            // 
            buttonPotenzieren.BackColor = SystemColors.AppWorkspace;
            buttonPotenzieren.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            buttonPotenzieren.Location = new Point(307, 377);
            buttonPotenzieren.Name = "buttonPotenzieren";
            buttonPotenzieren.Size = new Size(66, 63);
            buttonPotenzieren.TabIndex = 18;
            buttonPotenzieren.Text = "x^";
            buttonPotenzieren.UseVisualStyleBackColor = false;
            buttonPotenzieren.Click += button10_Click;
            // 
            // buttonWurzel
            // 
            buttonWurzel.BackColor = SystemColors.AppWorkspace;
            buttonWurzel.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            buttonWurzel.Location = new Point(379, 170);
            buttonWurzel.Name = "buttonWurzel";
            buttonWurzel.Size = new Size(66, 63);
            buttonWurzel.TabIndex = 19;
            buttonWurzel.Text = "√";
            buttonWurzel.UseVisualStyleBackColor = false;
            buttonWurzel.Click += buttonWurzel_Click;
            // 
            // buttonLogarithmus
            // 
            buttonLogarithmus.BackColor = SystemColors.AppWorkspace;
            buttonLogarithmus.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            buttonLogarithmus.Location = new Point(307, 308);
            buttonLogarithmus.Name = "buttonLogarithmus";
            buttonLogarithmus.Size = new Size(66, 63);
            buttonLogarithmus.TabIndex = 20;
            buttonLogarithmus.Text = "log";
            buttonLogarithmus.UseVisualStyleBackColor = false;
            buttonLogarithmus.Click += buttonLogarithmus_Click;
            // 
            // buttonFakultaet
            // 
            buttonFakultaet.BackColor = SystemColors.AppWorkspace;
            buttonFakultaet.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            buttonFakultaet.Location = new Point(379, 101);
            buttonFakultaet.Name = "buttonFakultaet";
            buttonFakultaet.Size = new Size(66, 63);
            buttonFakultaet.TabIndex = 21;
            buttonFakultaet.Text = "!";
            buttonFakultaet.UseVisualStyleBackColor = false;
            buttonFakultaet.Click += buttonFakultaet_Click;
            // 
            // buttonSinus
            // 
            buttonSinus.BackColor = SystemColors.AppWorkspace;
            buttonSinus.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            buttonSinus.Location = new Point(307, 101);
            buttonSinus.Name = "buttonSinus";
            buttonSinus.Size = new Size(66, 63);
            buttonSinus.TabIndex = 22;
            buttonSinus.Text = "sin";
            buttonSinus.UseVisualStyleBackColor = false;
            buttonSinus.Click += buttonSinus_Click;
            // 
            // buttonCosinus
            // 
            buttonCosinus.BackColor = SystemColors.AppWorkspace;
            buttonCosinus.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            buttonCosinus.Location = new Point(307, 170);
            buttonCosinus.Name = "buttonCosinus";
            buttonCosinus.Size = new Size(66, 63);
            buttonCosinus.TabIndex = 23;
            buttonCosinus.Text = "cos";
            buttonCosinus.UseVisualStyleBackColor = false;
            buttonCosinus.Click += buttonCosinus_Click;
            // 
            // buttonTangens
            // 
            buttonTangens.BackColor = SystemColors.AppWorkspace;
            buttonTangens.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            buttonTangens.Location = new Point(307, 239);
            buttonTangens.Name = "buttonTangens";
            buttonTangens.Size = new Size(66, 63);
            buttonTangens.TabIndex = 24;
            buttonTangens.Text = "tan";
            buttonTangens.UseVisualStyleBackColor = false;
            buttonTangens.Click += buttonTangens_Click;
            // 
            // buttonKomma
            // 
            buttonKomma.BackColor = SystemColors.AppWorkspace;
            buttonKomma.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            buttonKomma.Location = new Point(9, 377);
            buttonKomma.Name = "buttonKomma";
            buttonKomma.Size = new Size(66, 63);
            buttonKomma.TabIndex = 25;
            buttonKomma.Text = ",";
            buttonKomma.UseVisualStyleBackColor = false;
            buttonKomma.Click += buttonKomma_Click;
            // 
            // buttonDelete
            // 
            buttonDelete.BackColor = SystemColors.AppWorkspace;
            buttonDelete.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            buttonDelete.Location = new Point(8, 101);
            buttonDelete.Name = "buttonDelete";
            buttonDelete.Size = new Size(66, 63);
            buttonDelete.TabIndex = 26;
            buttonDelete.Text = "⌫";
            buttonDelete.UseVisualStyleBackColor = false;
            buttonDelete.Click += buttonDelete_Click;
            // 
            // buttonClearEverything
            // 
            buttonClearEverything.BackColor = SystemColors.AppWorkspace;
            buttonClearEverything.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            buttonClearEverything.Location = new Point(153, 101);
            buttonClearEverything.Name = "buttonClearEverything";
            buttonClearEverything.Size = new Size(66, 63);
            buttonClearEverything.TabIndex = 27;
            buttonClearEverything.Text = "CE";
            buttonClearEverything.UseVisualStyleBackColor = false;
            buttonClearEverything.Click += buttonClearEverything_Click;
            // 
            // buttonPlusMinus
            // 
            buttonPlusMinus.BackColor = SystemColors.AppWorkspace;
            buttonPlusMinus.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            buttonPlusMinus.Location = new Point(153, 377);
            buttonPlusMinus.Name = "buttonPlusMinus";
            buttonPlusMinus.Size = new Size(66, 63);
            buttonPlusMinus.TabIndex = 28;
            buttonPlusMinus.Text = "±";
            buttonPlusMinus.UseVisualStyleBackColor = false;
            buttonPlusMinus.Click += buttonPlusMinus_Click;
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { standartToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(458, 24);
            menuStrip1.TabIndex = 29;
            menuStrip1.Text = "menuStrip1";
            // 
            // standartToolStripMenuItem
            // 
            standartToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { standartToolStripMenuItem1, wissenschaftlichToolStripMenuItem });
            standartToolStripMenuItem.Name = "standartToolStripMenuItem";
            standartToolStripMenuItem.Size = new Size(37, 20);
            standartToolStripMenuItem.Text = "File";
            standartToolStripMenuItem.Click += standartToolStripMenuItem_Click;
            // 
            // standartToolStripMenuItem1
            // 
            standartToolStripMenuItem1.Name = "standartToolStripMenuItem1";
            standartToolStripMenuItem1.Size = new Size(162, 22);
            standartToolStripMenuItem1.Text = "Standart";
            standartToolStripMenuItem1.Click += standartToolStripMenuItem1_Click;
            // 
            // wissenschaftlichToolStripMenuItem
            // 
            wissenschaftlichToolStripMenuItem.Name = "wissenschaftlichToolStripMenuItem";
            wissenschaftlichToolStripMenuItem.Size = new Size(162, 22);
            wissenschaftlichToolStripMenuItem.Text = "Wissenschaftlich";
            wissenschaftlichToolStripMenuItem.Click += wissenschaftlichToolStripMenuItem_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.WindowFrame;
            ClientSize = new Size(458, 449);
            Controls.Add(buttonPlusMinus);
            Controls.Add(buttonClearEverything);
            Controls.Add(buttonDelete);
            Controls.Add(buttonKomma);
            Controls.Add(buttonTangens);
            Controls.Add(buttonCosinus);
            Controls.Add(buttonSinus);
            Controls.Add(buttonFakultaet);
            Controls.Add(buttonLogarithmus);
            Controls.Add(buttonWurzel);
            Controls.Add(buttonPotenzieren);
            Controls.Add(buttonClear);
            Controls.Add(button0);
            Controls.Add(buttonEQL);
            Controls.Add(buttonDIV);
            Controls.Add(buttonMULT);
            Controls.Add(buttonSUB);
            Controls.Add(buttonADD);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(tB_1);
            Controls.Add(menuStrip1);
            ForeColor = SystemColors.ControlText;
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            ShowIcon = false;
            Text = "Calculator";
            Load += Form1_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox tB_1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button buttonADD;
        private Button buttonSUB;
        private Button buttonMULT;
        private Button buttonDIV;
        private Button buttonEQL;
        private Button button0;
        private Button buttonClear;
        private Button buttonPotenzieren;
        private Button buttonWurzel;
        private Button buttonLogarithmus;
        private Button buttonFakultaet;
        private Button buttonSinus;
        private Button buttonCosinus;
        private Button buttonTangens;
        private Button buttonKomma;
        private Button buttonDelete;
        private Button buttonClearEverything;
        private Button buttonPlusMinus;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem standartToolStripMenuItem;
        private ToolStripMenuItem standartToolStripMenuItem1;
        private ToolStripMenuItem wissenschaftlichToolStripMenuItem;
    }
}
