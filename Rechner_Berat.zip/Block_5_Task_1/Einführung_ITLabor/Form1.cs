using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Block_5_Task_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            KeyPreview = true;
            KeyDown += MainForm_KeyDown;
        }

        string option, calcTotal;
        double num1, num2, result;

        private void Form1_Load(object sender, EventArgs e)
        {
            tB_1.Text = "0";
            this.Width = 317; //467; 488
            this.Height = 488;
        }


        private void MainForm_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Enter: buttonEQL.PerformClick(); break;
                case Keys.D0: case Keys.NumPad0: button0.PerformClick(); break;
                case Keys.D1: case Keys.NumPad1: button1.PerformClick(); break;
                case Keys.D2: case Keys.NumPad2: button2.PerformClick(); break;
                case Keys.D3: case Keys.NumPad3: button3.PerformClick(); break;
                case Keys.D4: case Keys.NumPad4: button4.PerformClick(); break;
                case Keys.D5: case Keys.NumPad5: button5.PerformClick(); break;
                case Keys.D6: case Keys.NumPad6: button6.PerformClick(); break;
                case Keys.D7: case Keys.NumPad7: button7.PerformClick(); break;
                case Keys.D8: case Keys.NumPad8: button8.PerformClick(); break;
                case Keys.D9: case Keys.NumPad9: button9.PerformClick(); break;
                case Keys.Oemcomma: case Keys.Decimal: buttonKomma.PerformClick(); break;
                case Keys.Back: buttonDelete.PerformClick(); break;
                case Keys.Add: buttonADD.PerformClick(); break;
                case Keys.Subtract: buttonSUB.PerformClick(); break;
                case Keys.Multiply: buttonMULT.PerformClick(); break;
                case Keys.Divide: buttonDIV.PerformClick(); break;
            }
        }

        private void button0_Click(object sender, EventArgs e)
        {
            tB_1.Text = tB_1.Text + button0.Text;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (tB_1.Text == "0")
                tB_1.Text = button1.Text;
            else
                tB_1.Text = tB_1.Text + button1.Text;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (tB_1.Text == "0")
                tB_1.Text = button2.Text;
            else
                tB_1.Text = tB_1.Text + button2.Text;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (tB_1.Text == "0")
                tB_1.Text = button3.Text;
            else
                tB_1.Text = tB_1.Text + button3.Text;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (tB_1.Text == "0")
                tB_1.Text = button4.Text;
            else
                tB_1.Text = tB_1.Text + button4.Text;
        }
        private void button5_Click(object sender, EventArgs e)
        {
            if (tB_1.Text == "0")
                tB_1.Text = button5.Text;
            else
                tB_1.Text = tB_1.Text + button5.Text;
        }
        private void button6_Click(object sender, EventArgs e)
        {
            if (tB_1.Text == "0")
                tB_1.Text = button6.Text;
            else
                tB_1.Text = tB_1.Text + button6.Text;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (tB_1.Text == "0")
                tB_1.Text = button7.Text;
            else
                tB_1.Text = tB_1.Text + button7.Text;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (tB_1.Text == "0")
                tB_1.Text = button8.Text;
            else
                tB_1.Text = tB_1.Text + button8.Text;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (tB_1.Text == "0")
                tB_1.Text = button9.Text;
            else
                tB_1.Text = tB_1.Text + button9.Text;
            
        }

        private void tB_1_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonADD_Click(object sender, EventArgs e)
        {
            option = "+";
            num1 = double.Parse(tB_1.Text);

            tB_1.Clear();
        }

        private void buttonSUB_Click(object sender, EventArgs e)
        {
            option = "-";
            num1 = double.Parse(tB_1.Text);

            tB_1.Clear();
        }

        private void buttonMULT_Click(object sender, EventArgs e)
        {
            option = "x";
            num1 = double.Parse(tB_1.Text);

            tB_1.Clear();
        }

        private void buttonDIV_Click(object sender, EventArgs e)
        {
            option = "➗";
            num1 = double.Parse(tB_1.Text);

            tB_1.Clear();
        }

        private void buttonEQL_Click(object sender, EventArgs e)
        {
            num2 = double.Parse(tB_1.Text);
            switch (option)
            {
                case "+":
                    result = num1 + num2;
                    break;
                case "-":
                    result = num1 - num2;
                    break;
                case "x":
                    if(num1 == 4 && num2 == 4)
                    {
                        result = 24;
                    }
                    else
                    {
                        result = num1 * num2;
                    }
                    break;
                case "➗":
                    result = num1 / num2;
                    break;

                case "x^":
                    result = Math.Pow(num1, num2);
                    break;
            }

            tB_1.Text = result + "";
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            tB_1.Clear();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            option = "x^";
            num1 = double.Parse(tB_1.Text);

            tB_1.Clear();
        }

        private void buttonKomma_Click(object sender, EventArgs e)
        {
            tB_1.Text = tB_1.Text + ",";
        }

        private void buttonClearEverything_Click(object sender, EventArgs e)
        {
            tB_1.Text = "0";
        }

        private void buttonClear_Click_1(object sender, EventArgs e)
        {
            tB_1.Text = "0";
            result = 0;
            num1 = 0;
            num2 = 0;
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (tB_1.Text.Length > 0)
            {
                tB_1.Text = tB_1.Text.Remove(tB_1.Text.Length - 1, 1);
            }

        }

        private void buttonLogarithmus_Click(object sender, EventArgs e)
        {
            double log = Convert.ToDouble(tB_1.Text);
            log = Math.Log10(log);
            tB_1.Text = Convert.ToString(log);
        }

        private void buttonWurzel_Click(object sender, EventArgs e)
        {
            double sqrt = Convert.ToDouble(tB_1.Text);
            sqrt = Math.Sqrt(sqrt);
            tB_1.Text = Convert.ToString(sqrt);
        }

        private void buttonSinus_Click(object sender, EventArgs e)
        {
            double sin = Convert.ToDouble(tB_1.Text);
            sin = Math.Sin(sin);
            tB_1.Text = Convert.ToString(sin);
        }

        private void buttonCosinus_Click(object sender, EventArgs e)
        {
            double cos = Convert.ToDouble(tB_1.Text);
            cos = Math.Cos(cos);
            tB_1.Text = Convert.ToString(cos);
        }

        private void buttonTangens_Click(object sender, EventArgs e)
        {
            double tan = Convert.ToDouble(tB_1.Text);
            tan = Math.Tan(tan);
            tB_1.Text = Convert.ToString(tan);
        }

        private void buttonPlusMinus_Click(object sender, EventArgs e)
        {
            double pm = Convert.ToDouble(tB_1.Text);
            tB_1.Text = Convert.ToString(-1 * pm);
        }

        private void buttonFakultaet_Click(object sender, EventArgs e)
        {
            double x = Convert.ToDouble(tB_1.Text);
            if (x == 0)
            {
                tB_1.Text = "1";
            }
            else
            {
                double ergebnis = 1;
                for (int i = 1; i <= x; i++)
                {
                    ergebnis *= i;
                }
                tB_1.Text = ergebnis.ToString();
            }
        }

        private void standartToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void standartToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Width = 317; //467; 488
            this.Height = 488;
            tB_1.Width = 283;

        }

        private void wissenschaftlichToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Width = 467; //467; 488
            this.Height = 488;
            tB_1.Width = 437;
        }
    }
}
